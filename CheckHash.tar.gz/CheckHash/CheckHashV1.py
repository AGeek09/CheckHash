# OpenSource Licensed under the Apache License, Version 2.0
# On Beta Testing , Request to Share Feedback Github.

import hashlib
import sys
import os

def compute_hashes(file_path):
    """Compute MD5, SHA1, and SHA256 hashes of the given file."""
    hash_results = {}
    
    with open(file_path, 'rb') as f:
        file_content = f.read()
        
        # Calculate MD5
        hash_results['MD5'] = hashlib.md5(file_content).hexdigest()
        # Calculate SHA1
        hash_results['SHA1'] = hashlib.sha1(file_content).hexdigest()
        # Calculate SHA256
        hash_results['SHA256'] = hashlib.sha256(file_content).hexdigest()
    
    return hash_results

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: CheckHashV1.py <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    if os.path.isfile(file_path):
        hashes = compute_hashes(file_path)
        print("\033[1;32;40m =========================***===========================")
        print("*** CheckHash V1.0 *** | Developed by : ALOK PUROHIT")
        print("\033[1;32;40m _______________________________________________________")
        print(f" \033[1;33;40m Hashes for Path :  {file_path}:")
        print()
         
        for alg, val in hashes.items():
            print(f"\033[1;36;40m {alg}: {val}")
            print()
            print("\033[1;34;40m_______________________________________________________")
            print()
    print("\033[1;32;40m  =========================***===========================")        
    input('\033[0;32;47m Press ENTER to exit')
    
    #else:
       # print("The specified path is not a valid file.")
   